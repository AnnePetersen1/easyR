require(shiny)
runApp(launch.browser=TRUE)
