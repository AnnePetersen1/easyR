initWD <- "P:/Kejsersnitprojekt/easyR/config/"

initData <- list(co2data = "co2data.rdata",
             irisdata = "iris.rdata")

initModels <- list(`model 1` = "m1.rdata",
               `model 2` = "model123.rdata",
               `Cox model` = "coxM.rdata")